// File: src/Main.java
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
        
        // Simple calculation: addition of two numbers
        int a = 5;
        int b = 10;
        int sum = a + b;
        System.out.println("Sum of " + a + " and " + b + " is " + sum);
    }
}
